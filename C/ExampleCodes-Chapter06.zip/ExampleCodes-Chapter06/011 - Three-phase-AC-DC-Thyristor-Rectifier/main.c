/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define TIM1_PSC_VALUE      169
#define TIM1_PERIOD_VALUE   20000-1
	
#define TIM2_PSC_VALUE      169
#define TIM2_PERIOD_VALUE   750-1
	
#define PWM_CH1             1<<8
#define PWM_CH2             1<<7
#define PWM_CH3             1<<9
#define PWM_CH4             1<<0
#define PWM_CH5             1<<10
#define PWM_CH6             1<<1

uint16_t halfCycleCH1=0,halfCycleCH2=0,halfCycleCH3=0;
uint8_t secondHalfCH1=0, secondHalfCH2=0, secondHalfCH3=0;
uint8_t intCHx=0;

void GPIO_Init(void);
void Timer1_Init(void);
void Timer2_Init(void);
void TIM1_CC_IRQHandler(void);
void TIM2_IRQHandler(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
  Timer1_Init();
  Timer2_Init();
	
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);

  // PA7, PA8, PA9, and PA10 as outputs
  GPIOA->MODER &= ~(GPIO_MODER_MODE7+GPIO_MODER_MODE8
                  +GPIO_MODER_MODE9+GPIO_MODER_MODE10);
  GPIOA->MODER |= (GPIO_MODER_MODE7_0+GPIO_MODER_MODE8_0
                  +GPIO_MODER_MODE9_0+GPIO_MODER_MODE10_0);
	
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);

  // PB0, PB1 as outputs
  GPIOB->MODER &= ~(GPIO_MODER_MODE0+GPIO_MODER_MODE1);
  GPIOB->MODER |= (GPIO_MODER_MODE0_0+GPIO_MODER_MODE1_0);
}

void Timer1_Init(void){
  RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
  TIM1->PSC = TIM1_PSC_VALUE;
  TIM1->ARR = TIM1_PERIOD_VALUE;
  TIM1->CNT = 0;
  
  // Select PWM Mode 2 output on channels 1 and 2
  TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M+TIM_CCMR1_OC2M);
  TIM1->CCMR1 |= (TIM_CCMR1_OC1M_0+TIM_CCMR1_OC1M_1+TIM_CCMR1_OC1M_2
                 +TIM_CCMR1_OC2M_0+TIM_CCMR1_OC2M_1+TIM_CCMR1_OC2M_2);
	
  // Select PWM Mode 2 output on channel 3
  TIM1->CCMR2 &= ~TIM_CCMR2_OC3M;
  TIM1->CCMR2 |= (TIM_CCMR2_OC3M_0+TIM_CCMR2_OC3M_1+TIM_CCMR2_OC3M_2);

  // Enable PWM CH1, CH2, and CH3
  TIM1->CCER |= (TIM_CCER_CC1E+TIM_CCER_CC2E+TIM_CCER_CC3E
                +TIM_CCER_CC1NE+TIM_CCER_CC2NE+TIM_CCER_CC3NE);
	
  // Main output enable (MOE)
  TIM1->BDTR |= TIM_BDTR_MOE;

  // Initial duty cycle PWM_DUTY_VALUE
  TIM1->CCR1 = 1667;
  TIM1->CCR2 = 5000;  // 1667+3333
  TIM1->CCR3 = 8333;  // 5000+3333
	
  // Enable TIM1 interrupt
  TIM1->DIER |= (TIM_DIER_UIE+TIM_DIER_CC1IE+TIM_DIER_CC2IE+TIM_DIER_CC3IE);
	
  // Timer 1 at NVIC (Interrupt Set-enable Register)
  NVIC->ISER[0] = (1<<TIM1_CC_IRQn);
  // Timer 1 Interrupt Set-pending Registers
  NVIC->ISPR[0] = (1<<TIM1_CC_IRQn);
					
  // Enable TIM1
  TIM1->CR1 |= TIM_CR1_CEN;
}

void Timer2_Init(void){
  RCC->APB1ENR1 |= RCC_APB1ENR1_TIM2EN;
	
  TIM2->PSC = TIM2_PSC_VALUE;
  TIM2->ARR = TIM2_PERIOD_VALUE;
  TIM2->CNT = 0;
	
  // Enable TIM2 interrupt
  TIM2->DIER |= TIM_DIER_UIE;
	
  // Enable TIM2
  TIM2->CR1 |= TIM_CR1_CEN;
	
  // Timer 2 at NVIC (Interrupt Set-enable Register)
  NVIC->ISER[0] = (1<<TIM2_IRQn);
  // Timer 2 Interrupt Set-pending Registers
  NVIC->ISPR[0] = (1<<TIM2_IRQn);
}

void TIM1_CC_IRQHandler(void){
	
  if (((TIM1->SR)&(TIM_SR_CC1IF))!=0){
    TIM1->SR &=~TIM_SR_CC1IF;
    intCHx=1;
  }
		
  if (((TIM1->SR)&(TIM_SR_CC2IF))!=0){
    TIM1->SR &=~TIM_SR_CC2IF;
    intCHx=2;
  }
	
  if (((TIM1->SR)&(TIM_SR_CC3IF))!=0){
    TIM1->SR &=~TIM_SR_CC3IF;
    intCHx=3;
  }

  TIM2->CNT = 0;

  switch (intCHx){
    
    case 1:
      if (secondHalfCH1==0){
        GPIOA->ODR ^= (PWM_CH1);
        GPIOB->ODR ^= (PWM_CH6);
        TIM1->CCR1 = 11666;  // Change the duty cycle for CH1
        secondHalfCH1=1;
     }else{
        GPIOA->ODR ^= (PWM_CH3);
        GPIOB->ODR ^= (PWM_CH4);
        TIM1->CCR1 = 1667;   // Change the duty cycle for CH1
        secondHalfCH1=0;
     }
    break;

    case 2:
      if (secondHalfCH2==0){
        GPIOA->ODR ^= ((PWM_CH2)+(PWM_CH1));
        TIM1->CCR2 = 14999;  // Change the duty cycle for CH2
        secondHalfCH2=1;		
      }else{
        GPIOA->ODR ^= (PWM_CH5);
        GPIOB->ODR ^= (PWM_CH4);
        TIM1->CCR2 = 5000;   // Change the duty cycle for CH2
        secondHalfCH2=0;	
      }
    break;

    case 3:
      if (secondHalfCH3==0){
        GPIOA->ODR ^= ((PWM_CH3)+(PWM_CH2));
        TIM1->CCR3 = 18332;  // Change the duty cycle for CH3
        secondHalfCH3=1;	
      }else{
        GPIOA->ODR ^= (PWM_CH5);
        GPIOB->ODR ^= (PWM_CH6);
        TIM1->CCR3 = 8333;   // Change the duty cycle for CH3
        secondHalfCH3=0;		
      }
    break;
	}
}

void TIM2_IRQHandler(void){
  TIM2->SR &= ~TIM_SR_UIF;
  if (intCHx!=0){
    GPIOA->ODR &= ~((PWM_CH1)+(PWM_CH2)+(PWM_CH3)+(PWM_CH5));
    GPIOB->ODR &= ~((PWM_CH4)+(PWM_CH6));
  }
}

