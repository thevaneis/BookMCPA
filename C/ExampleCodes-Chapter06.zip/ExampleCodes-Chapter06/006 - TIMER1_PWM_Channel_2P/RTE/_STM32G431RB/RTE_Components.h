
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'C_TIMER1_PWM_Channel_2P' 
 * Target:  'STM32G431RB' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"



#endif /* RTE_COMPONENTS_H */
