/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define TIM1_PSC_VALUE      1700-1
#define TIM1_PERIOD_VALUE   999-1
#define PWM_DUTY_VALUE      500

void GPIO_Init(void);
void Timer1_Init(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
	Timer1_Init();
	
  for (;;) {
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
  GPIOA->MODER &= ~(GPIO_MODER_MODE8+GPIO_MODER_MODE9);
  delay(5);
	// ; PA8, PA9 in alternate function mode
  GPIOA->MODER |= (GPIO_MODER_MODE8_1+GPIO_MODER_MODE9_1);
  delay(5);
	
	// PA8 for TIM1 CH1, PA8 for TIM1 CH2 (AF6)
	GPIOA->AFR[1] &= ~(GPIO_AFRH_AFSEL8+GPIO_AFRH_AFSEL9);
	GPIOA->AFR[1] |= (GPIO_AFRH_AFSEL8_1+GPIO_AFRH_AFSEL8_2+GPIO_AFRH_AFSEL9_1+GPIO_AFRH_AFSEL9_2);
}

void Timer1_Init(void){
  RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
  TIM1->PSC = TIM1_PSC_VALUE;
  TIM1->ARR = TIM1_PERIOD_VALUE;
  TIM1->CNT = 0;
  
  // Select PWM Mode 1 output on channel 1
	TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M+TIM_CCMR1_OC2M);
	TIM1->CCMR1 |= (TIM_CCMR1_OC1M_1+TIM_CCMR1_OC2M_1+TIM_CCMR1_OC1M_2+TIM_CCMR1_OC2M_2);

  // Main output enable (MOE)
	TIM1->BDTR |= TIM_BDTR_MOE;

  // Enable PWM CH1 and CH2
	TIM1->CCER |= (TIM_CCER_CC1E+TIM_CCER_CC2E);

  // Initial duty cycle PWM_DUTY_VALUE
	TIM1->CCR1 = PWM_DUTY_VALUE;
	TIM1->CCR2 = PWM_DUTY_VALUE;
					
  // Enable TIM1
	TIM1->CR1 |= TIM_CR1_CEN;
}

