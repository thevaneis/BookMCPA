/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define TIM1_PSC_VALUE      16
#define TIM1_PERIOD_VALUE   2125
	
void GPIO_Init(void);
void Timer1_Init(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
  Timer1_Init();

}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);

  // PA7, PA8, PA9, PA10 in alternate function mode
  GPIOA->MODER &= ~(GPIO_MODER_MODE7+GPIO_MODER_MODE8
                   +GPIO_MODER_MODE9+GPIO_MODER_MODE10);
  GPIOA->MODER |= (GPIO_MODER_MODE7_1+GPIO_MODER_MODE8_1
                  +GPIO_MODER_MODE9_1+GPIO_MODER_MODE10_1);	
					
  // PA7 for TIM1 (AF6)
  GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL7;
  GPIOA->AFR[0] |= (GPIO_AFRL_AFSEL7_1+GPIO_AFRL_AFSEL7_2);
	
  // PA8, PA9, and PA10 for TIM1 (AF6)
  GPIOA->AFR[1] &= ~(GPIO_AFRH_AFSEL8+GPIO_AFRH_AFSEL9+GPIO_AFRH_AFSEL10);
  GPIOA->AFR[1] |= (GPIO_AFRH_AFSEL8_1+GPIO_AFRH_AFSEL9_1+GPIO_AFRH_AFSEL10_1
                   +GPIO_AFRH_AFSEL8_2+GPIO_AFRH_AFSEL9_2+GPIO_AFRH_AFSEL10_2);

  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);
	
  GPIOB->MODER &= ~(GPIO_MODER_MODE0+GPIO_MODER_MODE1);
  GPIOB->MODER |= (GPIO_MODER_MODE0_1+GPIO_MODER_MODE1_1);

  // PB0, PB1 for TIM1 (AF6)
  GPIOB->AFR[0] &= ~(GPIO_AFRL_AFSEL0+GPIO_AFRL_AFSEL1);
  GPIOB->AFR[0] |= (GPIO_AFRL_AFSEL0_1+GPIO_AFRL_AFSEL1_1
                   +GPIO_AFRL_AFSEL0_2+GPIO_AFRL_AFSEL1_2);
}

void Timer1_Init(void){
  RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	
  //; Choose Center-aligned mode 1 for TIM1
  TIM1->CR1 &= ~TIM_CR1_CMS;
  TIM1->CR1 |= TIM_CR1_CMS_0;
	
  TIM1->PSC = TIM1_PSC_VALUE;
  TIM1->ARR = TIM1_PERIOD_VALUE;
  TIM1->CNT = 0;
  
  // Select PWM Mode 1 output on channels 1 and 2
  TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M+TIM_CCMR1_OC2M);
  TIM1->CCMR1 |= (TIM_CCMR1_OC1M_1+TIM_CCMR1_OC1M_2
                 +TIM_CCMR1_OC2M_1+TIM_CCMR1_OC2M_2);

  // Select PWM Mode 1 output on channel 3
  TIM1->CCMR2 &= ~TIM_CCMR2_OC3M;
  TIM1->CCMR2 |= (TIM_CCMR2_OC3M_1+TIM_CCMR2_OC3M_2);
	
  // Enable PWM CH1, CH2, and CH3
  TIM1->CCER |= (TIM_CCER_CC1E+TIM_CCER_CC2E+TIM_CCER_CC3E
                +TIM_CCER_CC1NE+TIM_CCER_CC2NE+TIM_CCER_CC3NE);
	
  // Main output enable (MOE)
  TIM1->BDTR |= TIM_BDTR_MOE;

  // Initial duty cycle PWM_DUTY_VALUE
  TIM1->CCR1 = 500;
  TIM1->CCR2 = 1000;
  TIM1->CCR3 = 1500;
	
  // Enable TIM1
  TIM1->CR1 |= TIM_CR1_CEN;
}





