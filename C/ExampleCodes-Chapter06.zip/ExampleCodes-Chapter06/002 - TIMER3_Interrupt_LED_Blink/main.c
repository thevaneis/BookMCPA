/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define TIM3_PSC_VALUE      17000-1
#define TIM3_PERIOD_VALUE   10000-1

void GPIO_Init(void);
void Timer3_Init(void);
void TIM3_IRQHandler(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
	Timer3_Init();
	
  for (;;) {
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
  GPIOA->MODER &= ~GPIO_MODER_MODE5;
  delay(5);
  GPIOA->MODER |= GPIO_MODER_MODE5_0;
  delay(5);
}

void Timer3_Init(void){
  RCC->APB1ENR1 |= RCC_APB1ENR1_TIM3EN;
  TIM3->PSC = TIM3_PSC_VALUE;
  TIM3->ARR = TIM3_PERIOD_VALUE;
  TIM3->CNT = 0;
  TIM3->DIER |= TIM_DIER_UIE;
  TIM3->CR1 |= TIM_CR1_CEN;
	
	// Timer 3 at NVIC (Interrupt Set-enable Register)
	NVIC->ISER[0] = (1<<TIM3_IRQn);
	// Timer 3 Interrupt Set-pending Registers
	NVIC->ISPR[0] = (1<<TIM3_IRQn);
	
}

void TIM3_IRQHandler(void){
	TIM3->SR &= ~TIM_SR_UIF;
  GPIOA->ODR ^= (1<<5);
}

