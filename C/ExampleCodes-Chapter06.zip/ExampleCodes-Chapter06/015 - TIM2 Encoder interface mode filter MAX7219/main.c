/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define MAX7219_CS          1<<12
#define MAX7219_CLK         1<<13
#define MAX7219_DIN         1<<15

uint8_t digit, LED;
uint32_t Cnt=0, tempCnt=0, divisor;

void GPIO_Init(void);
void MAX7219_Init(void);
void Timer4_Init(void);
void delay(volatile int i);
void sendWordToMax7219(uint16_t dataSend);
void MAX7219Display(void);

int main(void){
		
  GPIO_Init();
  Timer4_Init();
  MAX7219_Init();
	
  for (;;) {
    Cnt = TIM4->CNT;
    MAX7219Display();
    delay(5000);	
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);

  // PB6, PB7 in alternate function mode
  GPIOB->MODER &= ~(GPIO_MODER_MODE6+GPIO_MODER_MODE7);
  GPIOB->MODER |= (GPIO_MODER_MODE6_1+GPIO_MODER_MODE7_1);

  // PB6, PB7 for TIM4 as CH1 and CH2
  GPIOB->AFR[0] &= ~(GPIO_AFRL_AFSEL6+GPIO_AFRL_AFSEL7);
  GPIOB->AFR[0] |= (GPIO_AFRL_AFSEL6_1+GPIO_AFRL_AFSEL7_1);
					
  // Enable output mode for PB12, PB13, PB15
  GPIOB->MODER &= ~(GPIO_MODER_MODE12+GPIO_MODER_MODE13
                   +GPIO_MODER_MODE15);
  GPIOB->MODER |= (GPIO_MODER_MODE12_0+GPIO_MODER_MODE13_0
                  +GPIO_MODER_MODE15_0);
}

void Timer4_Init(void){
  // Timer 4 RCC enable
  RCC->APB1ENR1 |= RCC_APB1ENR1_TIM4EN;
					
  // Settings ARR value
  TIM4->ARR = 0xFFFF;

  // tim_ti1fp1 mapped on tim_ti1, tim_ti1fp2 mapped on tim_ti2 \cite[p.~1141]{ARM00006}
  TIM4->CCMR1 &= ~(TIM_CCMR1_CC1S+TIM_CCMR1_CC2S);	
  TIM4->CCMR1 |= (TIM_CCMR1_CC1S_0+TIM_CCMR1_CC2S_0);	
					
  // CH1 and CH2 filters
  TIM4->CCMR1 &= ~(TIM_CCMR1_IC1F+TIM_CCMR1_IC2F);	
  TIM4->CCMR1 |= (TIM_CCMR1_IC1F_1+TIM_CCMR1_IC1F_2
                 +TIM_CCMR1_IC2F_1+TIM_CCMR1_IC2F_2);	
					
  // tim_ti1fp1 non-inverted, tim_ti1fp1=tim_ti1
  TIM4->CCER &= ~(TIM_CCER_CC1P+TIM_CCER_CC1NP);	
					
  // tim_ti1fp2 non-inverted, tim_ti1fp2=tim_ti2
  TIM4->CCER &= ~(TIM_CCER_CC2P+TIM_CCER_CC2NP);	
					
  // Both inputs are active on both rising and falling edges
  TIM4->SMCR &= ~(TIM_SMCR_SMS);	
  TIM4->SMCR |= (TIM_SMCR_SMS_0+TIM_SMCR_SMS_1);	
					
  // Enable TIM4
  TIM4->CR1 |= TIM_CR1_CEN;	
}

void MAX7219Display(void){
  tempCnt = Cnt;
  divisor=10000000;
  for (LED=0; LED<8; LED++){
    digit=tempCnt/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    tempCnt %= divisor;
    divisor /= 10;
  }	
}

void sendWordToMax7219(uint16_t dataSend){
  uint8_t bitCnt;
  GPIOB->ODR &= ~(MAX7219_CS);         // LAT = 0
  delay(5);
  for (bitCnt=0; bitCnt<16 ; bitCnt++){
    if (dataSend&(0x8000>>bitCnt)){
      GPIOB->ODR |= MAX7219_DIN;       // DAT = 1
    }else{
      GPIOB->ODR &= ~(MAX7219_DIN);    // DAT = 0
    }
    delay(5);
    GPIOB->ODR |= MAX7219_CLK;         // CLK = 1
    delay(5);
    GPIOB->ODR &= ~(MAX7219_CLK);      // CLK = 0				
    delay(5);
  }
  GPIOB->ODR |= MAX7219_CS;            // LAT = 1
  delay(5);
}

void MAX7219_Init(void){
	// For test mode (all digits on) set to 0x01. 
	// Normally we want this off (0x0F)
	// sendWord(LED0, 0x0F, 0x00)
  sendWordToMax7219(0x0F00);

  // Set all digits off initially (0x0C)
  // sendWord(LED0, 0x0C, 0x00);
  sendWordToMax7219(0x0C00);

  // Set brightness for the digits to high(er) level than default minimum (Intensity Register Format)
  //  sendWord(LED0, 0x0A, 0x03);
  sendWordToMax7219(0x0A03);

  // Set decode mode for ALL digits to output actual ASCII chars rather than just
  // individual segments of a digit
  // sendWord(LED0, 0x09, 0xFF);
  sendWordToMax7219(0x09FF);

  // If first four digits not set it will display rubbish data (Code B Font) so use 'blank' from Register Data
  // sendWord(LED0, 0x01, 0x0F);
  sendWordToMax7219(0x010F);

  // sendWord(LED0, 0x02, 0x0F);
  sendWordToMax7219(0x020F);
					
  // sendWord(LED0, 0x03, 0x0F);
  sendWordToMax7219(0x030F);
					
  // sendWord(LED0, 0x04, 0x0F);
  sendWordToMax7219(0x040F);
					
  // sendWord(LED0, 0x05, 0x0F);
  sendWordToMax7219(0x050F);
					
  // sendWord(LED0, 0x06, 0x0F);
  sendWordToMax7219(0x060F);
					
  // sendWord(LED0, 0x07, 0x0F);
  sendWordToMax7219(0x070F);
					
  // sendWord(LED0, 0x08, 0x0F);
  sendWordToMax7219(0x080F);

  // Ensure ALL digits are displayed (Scan Limit Register)
  // sendWord(LED0, 0x0B, 0x07);
  sendWordToMax7219(0x0B07);

  // Turn display ON (boot up = shutdown display)
  // sendWord(LED0, 0x0C, 0x01);
  sendWordToMax7219(0x0C01);

}

