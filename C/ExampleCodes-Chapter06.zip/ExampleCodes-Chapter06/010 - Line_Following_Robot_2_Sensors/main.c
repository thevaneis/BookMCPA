/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define MAX7219_CS          1<<12
#define MAX7219_CLK         1<<13
#define MAX7219_DIN         1<<15

#define TIM1_PSC_VALUE      1700-1
#define TIM1_PERIOD_VALUE   999-1
#define PWM_DUTY_VALUE      500

#define BUT_RUN             1<<2
#define SENSOR_L            1<<10
#define SENSOR_R            1<<11
#define BUT_STOP            1<<7

#define STRAIGHT            1
#define STOP                3

#define BCCOEFF             500

uint8_t digit, LED;
uint32_t tempCycle;
uint32_t divisor;

uint32_t key;
uint16_t BouncingCycles=0;

uint16_t dutyCycleL=0, dutyCycleR=0;

uint8_t OpMode=0;

void GPIO_Init(void);
void MAX7219_Init(void);
void Timer1_Init(void);
void delay(volatile int i);
void sendWordToMax7219(uint16_t dataSend);
void displayDutyCycle(void);

int main(void){
		
  GPIO_Init();
	MAX7219_Init();
	Timer1_Init();
	
	dutyCycleL=0;
	dutyCycleR=0;
	displayDutyCycle();
	
  for (;;) {
    key=GPIOB->IDR;
		
    switch (key&((BUT_RUN)+(SENSOR_L)+(SENSOR_R)+(BUT_STOP))){
			
      case 0xC80:
        if (OpMode!=STRAIGHT){
          BouncingCycles++;
          if (BouncingCycles>=BCCOEFF){
            OpMode=STRAIGHT;
						dutyCycleL=500;
						dutyCycleR=500;
            TIM1->CCR1 = dutyCycleL;
	          TIM1->CCR2 = dutyCycleR;
            BouncingCycles=0;
          }
        }				
      break;
			
      case 0x484:
        if (OpMode!=STOP){
          BouncingCycles++;
          if (BouncingCycles>=BCCOEFF){
						dutyCycleL=100;
            TIM1->CCR1 = dutyCycleL;
            BouncingCycles=0;
					}
        }				
      break;	
				
      case 0x884:
        if (OpMode!=STOP){
          BouncingCycles++;
          if (BouncingCycles>=BCCOEFF){
						dutyCycleR=100;
            TIM1->CCR2 = dutyCycleR; 
            BouncingCycles=0;
					}
        }				
      break;	
				
      case 0xC04:
        if (OpMode!=STOP){
          BouncingCycles++;
          if (BouncingCycles>=BCCOEFF){
						OpMode=STOP;
						dutyCycleL=0;
						dutyCycleR=0;
              TIM1->CCR1 = dutyCycleL;
	            TIM1->CCR2 = dutyCycleR;
              BouncingCycles=0;
					}
        }				
      break;	

      default:
        BouncingCycles=0;
        if (OpMode==STRAIGHT){
					dutyCycleL=500;
					dutyCycleR=500;
          TIM1->CCR1 = dutyCycleL;
          TIM1->CCR2 = dutyCycleR;
        }	
    }
		displayDutyCycle();
    delay(5000);
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
  GPIOA->MODER &= ~(GPIO_MODER_MODE8+GPIO_MODER_MODE9);
  delay(5);
	
  // PA7, PA10 as outputs
  GPIOA->MODER &= ~(GPIO_MODER_MODE7+GPIO_MODER_MODE10);
	GPIOA->MODER |= (GPIO_MODER_MODE7_0+GPIO_MODER_MODE10_0);
	
	// ; PA8, PA9 in alternate function mode
  GPIOA->MODER |= (GPIO_MODER_MODE8_1+GPIO_MODER_MODE9_1);
  delay(5);
	
	// PA8 for TIM1 CH1, PA8 for TIM1 CH2 (AF6)
	GPIOA->AFR[1] &= ~(GPIO_AFRH_AFSEL8+GPIO_AFRH_AFSEL9);
	GPIOA->AFR[1] |= (GPIO_AFRH_AFSEL8_1+GPIO_AFRH_AFSEL8_2+GPIO_AFRH_AFSEL9_1+GPIO_AFRH_AFSEL9_2);

  // Enable the clock to the GPIOB Port
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
	
  // PB12, PB13, and PB15 as outputs
  GPIOB->MODER &= ~(GPIO_MODER_MODE12+GPIO_MODER_MODE13+GPIO_MODER_MODE15);
	GPIOB->MODER |= (GPIO_MODER_MODE12_0+GPIO_MODER_MODE13_0+GPIO_MODER_MODE15_0);
					
  // Enable the clock to the GPIOC Port
	//RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;
					
  // Enable input mode for PC6, PC7, PC8, PC9
  GPIOB->MODER &= ~(GPIO_MODER_MODE2+GPIO_MODER_MODE7+GPIO_MODER_MODE10+GPIO_MODER_MODE11);

  // Enable pull-up resistors
  GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPD2+GPIO_PUPDR_PUPD7);
	GPIOB->PUPDR |= (GPIO_PUPDR_PUPD2_0+GPIO_PUPDR_PUPD7_0);	
}

void Timer1_Init(void){
  RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
  TIM1->PSC = TIM1_PSC_VALUE;
  TIM1->ARR = TIM1_PERIOD_VALUE;
  TIM1->CNT = 0;
  
  // Select PWM Mode 1 output on channel 1
	TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M+TIM_CCMR1_OC2M);
	TIM1->CCMR1 |= (TIM_CCMR1_OC1M_1+TIM_CCMR1_OC2M_1+TIM_CCMR1_OC1M_2+TIM_CCMR1_OC2M_2);

  // Main output enable (MOE)
	TIM1->BDTR |= TIM_BDTR_MOE;

  // Enable PWM CH1 and CH2
	TIM1->CCER |= (TIM_CCER_CC1E+TIM_CCER_CC2E);

  // Initial duty cycle PWM_DUTY_VALUE
	TIM1->CCR1 = 0;
	TIM1->CCR2 = 0;
					
  // Enable TIM1
	TIM1->CR1 |= TIM_CR1_CEN;
}

void displayDutyCycle(void){
  tempCycle = dutyCycleL;
  divisor=100;
  for (LED=0; LED<3; LED++){
    digit=tempCycle/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    tempCycle %= divisor;
    divisor /= 10;
  }	
  tempCycle = dutyCycleR;
  divisor=100;
  for (LED=5; LED<8; LED++){
    digit=tempCycle/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    tempCycle %= divisor;
    divisor /= 10;
  }		
}

void sendWordToMax7219(uint16_t dataSend){
  uint8_t bitCnt;
  GPIOB->ODR &= ~(MAX7219_CS);         // LAT = 0
  delay(5);
  for (bitCnt=0; bitCnt<16 ; bitCnt++){
    if (dataSend&(0x8000>>bitCnt)){
      GPIOB->ODR |= MAX7219_DIN;       // DAT = 1
    }else{
      GPIOB->ODR &= ~(MAX7219_DIN);    // DAT = 0
    }
    delay(5);
    GPIOB->ODR |= MAX7219_CLK;         // CLK = 1
    delay(5);
    GPIOB->ODR &= ~(MAX7219_CLK);      // CLK = 0				
    delay(5);
  }
  GPIOB->ODR |= MAX7219_CS;            // LAT = 1
  delay(5);
}

void MAX7219_Init(void){
	// For test mode (all digits on) set to 0x01. 
	// Normally we want this off (0x0F)
	// sendWord(LED0, 0x0F, 0x00)
  sendWordToMax7219(0x0F00);

  // Set all digits off initially (0x0C)
  // sendWord(LED0, 0x0C, 0x00);
  sendWordToMax7219(0x0C00);

  // Set brightness for the digits to high(er) level than default minimum (Intensity Register Format)
  //  sendWord(LED0, 0x0A, 0x03);
  sendWordToMax7219(0x0A03);

  // Set decode mode for ALL digits to output actual ASCII chars rather than just
  // individual segments of a digit
  // sendWord(LED0, 0x09, 0xFF);
  sendWordToMax7219(0x09FF);

  // If first four digits not set it will display rubbish data (Code B Font) so use 'blank' from Register Data
  // sendWord(LED0, 0x01, 0x0F);
  sendWordToMax7219(0x010F);

  // sendWord(LED0, 0x02, 0x0F);
  sendWordToMax7219(0x020F);
					
  // sendWord(LED0, 0x03, 0x0F);
  sendWordToMax7219(0x030F);
					
  // sendWord(LED0, 0x04, 0x0F);
  sendWordToMax7219(0x040F);
					
  // sendWord(LED0, 0x05, 0x0F);
  sendWordToMax7219(0x050F);
					
  // sendWord(LED0, 0x06, 0x0F);
  sendWordToMax7219(0x060F);
					
  // sendWord(LED0, 0x07, 0x0F);
  sendWordToMax7219(0x070F);
					
  // sendWord(LED0, 0x08, 0x0F);
  sendWordToMax7219(0x080F);

  // Ensure ALL digits are displayed (Scan Limit Register)
  // sendWord(LED0, 0x0B, 0x07);
  sendWordToMax7219(0x0B07);

  // Turn display ON (boot up = shutdown display)
  // sendWord(LED0, 0x0C, 0x01);
  sendWordToMax7219(0x0C01);

}

