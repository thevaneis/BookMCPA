
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'C_SABS-Test-MAX7219' 
 * Target:  'STM32G431RB' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"



#endif /* RTE_COMPONENTS_H */
