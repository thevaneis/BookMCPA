
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'C_ADC1-PC0-PC1-MAX7219-Filter-Single' 
 * Target:  'STM32G431RB' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"



#endif /* RTE_COMPONENTS_H */
