/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define MAX7219_CS          1<<12
#define MAX7219_CLK         1<<13
#define MAX7219_DIN         1<<15

uint8_t digit, LED;
uint32_t divisor;

uint16_t value_ADC1=0, value_ADC2=0;
uint16_t prev_ADC1=0, prev_ADC2=0;
uint16_t temp_ADC=0;

uint16_t adc_value[2];

void GPIO_Init(void);
void ADC1_Init(void);
void MAX7219_Init(void);
void delay(volatile int i);
void sendWordToMax7219(uint16_t dataSend);
void displayADCValues(void);

int main(void){
		
  GPIO_Init();
  ADC1_Init();
  MAX7219_Init();
	
  for (;;) {
		
    // ADC1 start conversion
    ADC1->CR |= ADC_CR_ADSTART;

    // Check_conversion_CH1
    while (((ADC1->ISR)&(ADC_ISR_EOC))==0){}
    value_ADC1 = ADC1->DR;

    // Check_conversion_CH2
    while (((ADC1->ISR)&(ADC_ISR_EOC))==0){}
    value_ADC2 = ADC1->DR;
			
    value_ADC1 = (49*prev_ADC1+value_ADC1)/50;
    value_ADC2 = (49*prev_ADC2+value_ADC2)/50;
			
    prev_ADC1=value_ADC1;
    prev_ADC2=value_ADC2;
		
    displayADCValues();
    delay(50000);	
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;
  delay(5);

  // Enable analog mode for PC0 and PC1
  GPIOC->MODER |= (GPIO_MODER_MODE0+GPIO_MODER_MODE1);
	
  // No pull-down resistor
  GPIOC->PUPDR &= ~(GPIO_PUPDR_PUPD0+GPIO_PUPDR_PUPD1);
	
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);
				
  // Enable output mode for PB12, PB13, PB15
  GPIOB->MODER &= ~(GPIO_MODER_MODE12+GPIO_MODER_MODE13
                   +GPIO_MODER_MODE15);
  GPIOB->MODER |= (GPIO_MODER_MODE12_0+GPIO_MODER_MODE13_0
                  +GPIO_MODER_MODE15_0);
}

void ADC1_Init(void){
	
  // Step 1. Enable clock for ADC1, ADC2 
  RCC->AHB2ENR |= RCC_AHB2ENR_ADC12EN;

  // Enable ADC1/2 clock source selection
  RCC->CCIPR &= ~(RCC_CCIPR_ADC12SEL);	
  RCC->CCIPR |= (RCC_CCIPR_ADC12SEL_1);	
					
  // Disable continous mode 
  ADC1->CFGR &= ~(ADC_CFGR_CONT);
					
  // Enable Auto-delayed conversion mode
  ADC1->CFGR |= ADC_CFGR_AUTDLY;
	
  // Select prescale for ADC1
  ADC12_COMMON->CCR &= ~(ADC_CCR_PRESC);
  ADC12_COMMON->CCR |= (ADC_CCR_PRESC_0+ADC_CCR_PRESC_1+ADC_CCR_PRESC_3);

  // Select sampling time for channel 1 (111 = 640.5 ADC clock cycles)
  ADC1->SMPR1 |= ADC_SMPR1_SMP1;

  // Select ADC group regular sequencer scan length (0001=2 conversion) 
  ADC1->SQR1 &= ~(ADC_SQR1_L);
  ADC1->SQR1 |= (ADC_SQR1_L_0);
					
  // Enable PC0 as ADC IN6
  ADC1->SQR1 &= ~(ADC_SQR1_SQ1);
  ADC1->SQR1 |= (ADC_SQR1_SQ1_1+ADC_SQR1_SQ1_2);

  // Enable PC1 as ADC IN7
  ADC1->SQR1 &= ~(ADC_SQR1_SQ2);
  ADC1->SQR1 |= (ADC_SQR1_SQ2_0+ADC_SQR1_SQ2_1+ADC_SQR1_SQ2_2);
	
  // Disable the Deep-power-down mode 
  ADC1->CR &= ~(ADC_CR_DEEPPWD);
					
  // Enable the ADC voltage regulator 
  ADC1->CR |= ADC_CR_ADVREGEN;
					
  // Clear ADC ready bit by writing 1 to it  \cite[p.~613]{ARM00006}
  ADC1->ISR |= ADC_ISR_ADRDY;

  // Enable ADC1 
  ADC1->CR |= ADC_CR_ADEN;

  // Wait until ADRDY = 1  \cite[p.~613]{ARM00006}
  while (((ADC1->ISR)&(ADC_ISR_ADRDY))==0){};
}


void displayADCValues(void){
  temp_ADC = value_ADC1;
  divisor=1000;
  for (LED=0; LED<4; LED++){
    digit=temp_ADC/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    temp_ADC %= divisor;
    divisor /= 10;
  }	
  temp_ADC = value_ADC2;
  divisor=1000;
  for (LED=4; LED<8; LED++){
    digit=temp_ADC/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    temp_ADC %= divisor;
    divisor /= 10;
  }		
}

void sendWordToMax7219(uint16_t dataSend){
  uint8_t bitCnt;
  GPIOB->ODR &= ~(MAX7219_CS);         // LAT = 0
  delay(5);
  for (bitCnt=0; bitCnt<16 ; bitCnt++){
    if (dataSend&(0x8000>>bitCnt)){
      GPIOB->ODR |= MAX7219_DIN;       // DAT = 1
    }else{
      GPIOB->ODR &= ~(MAX7219_DIN);    // DAT = 0
    }
    delay(5);
    GPIOB->ODR |= MAX7219_CLK;         // CLK = 1
    delay(5);
    GPIOB->ODR &= ~(MAX7219_CLK);      // CLK = 0				
    delay(5);
  }
  GPIOB->ODR |= MAX7219_CS;            // LAT = 1
  delay(5);
}

void MAX7219_Init(void){
	// For test mode (all digits on) set to 0x01. 
	// Normally we want this off (0x0F)
	// sendWord(LED0, 0x0F, 0x00)
  sendWordToMax7219(0x0F00);

  // Set all digits off initially (0x0C)
  // sendWord(LED0, 0x0C, 0x00);
  sendWordToMax7219(0x0C00);

  // Set brightness for the digits to high(er) level than default minimum (Intensity Register Format)
  //  sendWord(LED0, 0x0A, 0x03);
  sendWordToMax7219(0x0A03);

  // Set decode mode for ALL digits to output actual ASCII chars rather than just
  // individual segments of a digit
  // sendWord(LED0, 0x09, 0xFF);
  sendWordToMax7219(0x09FF);

  // If first four digits not set it will display rubbish data (Code B Font) so use 'blank' from Register Data
  // sendWord(LED0, 0x01, 0x0F);
  sendWordToMax7219(0x010F);

  // sendWord(LED0, 0x02, 0x0F);
  sendWordToMax7219(0x020F);
					
  // sendWord(LED0, 0x03, 0x0F);
  sendWordToMax7219(0x030F);
					
  // sendWord(LED0, 0x04, 0x0F);
  sendWordToMax7219(0x040F);
					
  // sendWord(LED0, 0x05, 0x0F);
  sendWordToMax7219(0x050F);
					
  // sendWord(LED0, 0x06, 0x0F);
  sendWordToMax7219(0x060F);
					
  // sendWord(LED0, 0x07, 0x0F);
  sendWordToMax7219(0x070F);
					
  // sendWord(LED0, 0x08, 0x0F);
  sendWordToMax7219(0x080F);

  // Ensure ALL digits are displayed (Scan Limit Register)
  // sendWord(LED0, 0x0B, 0x07);
  sendWordToMax7219(0x0B07);

  // Turn display ON (boot up = shutdown display)
  // sendWord(LED0, 0x0C, 0x01);
  sendWordToMax7219(0x0C01);

}

