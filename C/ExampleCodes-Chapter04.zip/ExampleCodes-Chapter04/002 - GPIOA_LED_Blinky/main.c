/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

void GPIO_Init(void);
void SystemClock_Init(void);

int main(void){
	GPIO_Init();	
  for (;;) {
    volatile unsigned int i;
		GPIOA->ODR ^= 1<<5;
    i = 5000000; // Delay
    do (i--);
    while (i != 0);
  }	
}


void GPIO_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	GPIOA->MODER &= ~GPIO_MODER_MODE5;
	GPIOA->MODER |= GPIO_MODER_MODE5_0;
  GPIOA->ODR |= 1<<5;	
}


