/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

uint8_t Cnt=0;

void GPIO_Init(void);
void delay(volatile int i);

int main(void){
	GPIO_Init();
  for (;;) {
    volatile unsigned int i,j;
		for (Cnt=0; Cnt<8; Cnt++){
			if (Cnt<2){
        j=Cnt;
			}else{
				j=Cnt+2;
			}
		  GPIOA->ODR = (0xFFFF&~(1<<j));
			delay(5000000);
    }	
  }
}

void GPIO_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	delay(5);
	GPIOA->MODER &= ~(GPIO_MODER_MODE0+GPIO_MODER_MODE1+GPIO_MODER_MODE4+GPIO_MODER_MODE5+GPIO_MODER_MODE6+GPIO_MODER_MODE7+GPIO_MODER_MODE8+GPIO_MODER_MODE9);
	delay(5);
	GPIOA->MODER |= (GPIO_MODER_MODE0_0+GPIO_MODER_MODE1_0+GPIO_MODER_MODE4_0+GPIO_MODER_MODE5_0+GPIO_MODER_MODE6_0+GPIO_MODER_MODE7_0+GPIO_MODER_MODE8_0+GPIO_MODER_MODE9_0);
	delay(5);
}

void delay(volatile int i){
    while(i--) continue;
}

