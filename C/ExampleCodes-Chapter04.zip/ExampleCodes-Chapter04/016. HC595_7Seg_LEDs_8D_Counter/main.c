/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define MAX 99999999

#define HC595_SCK 1<<13
#define HC595_LAT 1<<12
#define HC595_DAT 1<<15

volatile uint16_t LEDCodes[11]={0xC0,0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

uint8_t displayCnt=0;
uint8_t digit, LED;
uint32_t numCount=0,numTemp;
uint32_t divisor=10000000;

void GPIO_Init(void);
void shiftout16bits(uint16_t dataSend);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
	
  for (;;) {
    if (numCount>MAX){
      numCount=0;
    }
    numTemp = numCount;
    divisor=10000000;
    for (LED=0; LED<8; LED++){
      digit=numTemp/divisor;
      shiftout16bits((LEDCodes[digit+1]<<8)|(0x80>>LED));
      delay(50000);
      numTemp %= divisor;
      divisor /= 10;
    }
		
    displayCnt++;
    if (displayCnt>=50){
      numCount++;
      displayCnt=0;
    }
  }
}

void shiftout16bits(uint16_t dataSend){
  uint8_t bitCnt;
  GPIOB->ODR &= ~(HC595_LAT);        // LAT = 0
  delay(5);
  for (bitCnt=0; bitCnt<16 ; bitCnt++){
    if (dataSend&(0x8000>>bitCnt)){
      GPIOB->ODR |= HC595_DAT;       // DAT = 1
    }else{
      GPIOB->ODR &= ~(HC595_DAT);    // DAT = 0
    }
    delay(5);
    GPIOB->ODR &= ~(HC595_SCK);      // SCK = 0
    delay(5);
    GPIOB->ODR |= HC595_SCK;         // SCK = 1		
    delay(5);
  }
  GPIOB->ODR |= HC595_LAT;           // LAT = 1
  delay(5);
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  GPIOB->MODER &= ~(GPIO_MODER_MODE12+GPIO_MODER_MODE13+GPIO_MODER_MODE15);
  GPIOB->MODER |= (GPIO_MODER_MODE12_0+GPIO_MODER_MODE13_0+GPIO_MODER_MODE15_0);
}



