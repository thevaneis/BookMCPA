/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define A1 1<<0      // Pink
#define A2 1<<7      // Orange
#define B1 1<<8      // Yellow
#define B2 1<<9      // Blue

void GPIO_Init(void);
void delay(volatile int i);

int main(void){
	GPIO_Init();
  for (;;) {
		// S1
		GPIOB->ODR &= ~(A1);
		
		GPIOA->ODR &= (A2)+(B1)+(B2);
		GPIOA->ODR |= (A2)+(B1)+(B2);
    delay(500000);
		
		// S2
		GPIOB->ODR |= (A1);
		
		GPIOA->ODR &= (A2)+(B2);
		GPIOA->ODR |= (A2)+(B2);
    delay(500000);
		
		// S3
		GPIOA->ODR &= (B1)+(B2);
		GPIOA->ODR |= (B1)+(B2);
    delay(500000);
		
		// S4
		GPIOA->ODR &= (A2)+(B1);
		GPIOA->ODR |= (A2)+(B1);
    delay(500000);
  }
}

void GPIO_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
	GPIOA->MODER &= ~(GPIO_MODER_MODE7+GPIO_MODER_MODE8+GPIO_MODER_MODE9);
  delay(5);	
	GPIOA->MODER |= (GPIO_MODER_MODE7_0+GPIO_MODER_MODE8_0+GPIO_MODER_MODE9_0);
  delay(5);

	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);
	GPIOB->MODER &= ~GPIO_MODER_MODE0;
  delay(5);	
	GPIOB->MODER |= GPIO_MODER_MODE0_0;
  delay(5);		
}

void delay(volatile int i){
    while(i--) continue;
}



