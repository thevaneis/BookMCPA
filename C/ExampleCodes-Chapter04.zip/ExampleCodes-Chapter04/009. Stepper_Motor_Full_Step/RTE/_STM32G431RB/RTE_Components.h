
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'C_Stepper_Motor_Full_Step' 
 * Target:  'STM32G431RB' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"



#endif /* RTE_COMPONENTS_H */
