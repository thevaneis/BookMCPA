/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define DLVAL 25
#define MAX 99999999
#define BCCOEFF       500

#define MAX7219_CS    1<<12
#define MAX7219_CLK   1<<13
#define MAX7219_DIN   1<<15

#define BUTTON1       1<<2
#define BUTTON2       1<<6

volatile uint16_t LEDCodes[11]={0xC0,0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

uint32_t displayCnt=0;
uint8_t digit, LED;
uint32_t numCount=0,numTemp;
uint32_t divisor=10000000;

uint32_t key;
uint16_t BouncingCycles=0;

void GPIO_Init(void);
void MAX7219_Init(void);
void sendWordToMax7219(uint16_t dataSend);
void MAX7219Display(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
  MAX7219_Init();
  MAX7219Display();
	
  for (;;) {
		
    key=GPIOB->IDR;
    if (!(key&(BUTTON1))){
      if (numCount<MAX){
        BouncingCycles++;
        if (BouncingCycles>=BCCOEFF){
          numCount++;
          MAX7219Display();
          BouncingCycles=0;
        }
      }
    }else{				
			if (!(key&(BUTTON2))){
        if (numCount>0){
          BouncingCycles++;
          if (BouncingCycles>=BCCOEFF){
            numCount--;
            MAX7219Display();
            BouncingCycles=0;
          }
        }
      }	else{			
        BouncingCycles=0;
			}
    }
    delay(5000);		
  }
}

void MAX7219Display(void){
  numTemp = numCount;
  divisor=10000000;
  for (LED=0; LED<8; LED++){
    digit=numTemp/divisor;
    sendWordToMax7219(((8-LED)<<8)|digit);
    numTemp %= divisor;
    divisor /= 10;
  }	
}

void sendWordToMax7219(uint16_t dataSend){
  uint8_t bitCnt;
  GPIOB->ODR &= ~(MAX7219_CS);        // LAT = 0
  delay(5);
  for (bitCnt=0; bitCnt<16 ; bitCnt++){
    if (dataSend&(0x8000>>bitCnt)){
      GPIOB->ODR |= MAX7219_DIN;       // DAT = 1
    }else{
      GPIOB->ODR &= ~(MAX7219_DIN);    // DAT = 0
    }
    delay(5);
    GPIOB->ODR |= MAX7219_CLK;         // CLK = 1
    delay(5);
    GPIOB->ODR &= ~(MAX7219_CLK);      // CLK = 0				
    delay(5);
	}
  GPIOB->ODR |= MAX7219_CS;            // LAT = 1
  delay(5);
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  GPIOA->MODER &= ~GPIO_MODER_MODE5;
	GPIOA->MODER |= GPIO_MODER_MODE5_0;
	
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
	GPIOB->MODER &= ~(GPIO_MODER_MODE12+GPIO_MODER_MODE13+GPIO_MODER_MODE15);
	GPIOB->MODER |= (GPIO_MODER_MODE12_0+GPIO_MODER_MODE13_0+GPIO_MODER_MODE15_0);
	
	GPIOB->MODER &= ~(GPIO_MODER_MODE2+GPIO_MODER_MODE6);
	GPIOB->PUPDR &= ~(GPIO_MODER_MODE2+GPIO_MODER_MODE6);
	// Enable pull-up resistor
	GPIOB->PUPDR |= (GPIO_MODER_MODE2_0+GPIO_MODER_MODE6_0);
}

void MAX7219_Init(void){
	// For test mode (all digits on) set to 0x01. 
	// Normally we want this off (0x0F)
	// sendWord(LED0, 0x0F, 0x00)
	sendWordToMax7219(0x0F00);

	// Set all digits off initially (0x0C)
  // sendWord(LED0, 0x0C, 0x00);
	sendWordToMax7219(0x0C00);

  // Set brightness for the digits to high(er) level than default minimum (Intensity Register Format)
  //  sendWord(LED0, 0x0A, 0x03);
	sendWordToMax7219(0x0A03);

  // Set decode mode for ALL digits to output actual ASCII chars rather than just
  // individual segments of a digit
  // sendWord(LED0, 0x09, 0xFF);
	sendWordToMax7219(0x09FF);

  // If first four digits not set it will display rubbish data (Code B Font) so use 'blank' from Register Data
  // sendWord(LED0, 0x01, 0x0F);
	sendWordToMax7219(0x010F);

  // sendWord(LED0, 0x02, 0x0F);
	sendWordToMax7219(0x020F);
					
  // sendWord(LED0, 0x03, 0x0F);
	sendWordToMax7219(0x030F);
					
  // sendWord(LED0, 0x04, 0x0F);
	sendWordToMax7219(0x040F);
					
  // sendWord(LED0, 0x05, 0x0F);
	sendWordToMax7219(0x050F);
					
  // sendWord(LED0, 0x06, 0x0F);
	sendWordToMax7219(0x060F);
					
  // sendWord(LED0, 0x07, 0x0F);
	sendWordToMax7219(0x070F);
					
  // sendWord(LED0, 0x08, 0x0F);
	sendWordToMax7219(0x080F);

  // Ensure ALL digits are displayed (Scan Limit Register)
  // sendWord(LED0, 0x0B, 0x07);
	sendWordToMax7219(0x0B07);

  // Turn display ON (boot up = shutdown display)
  // sendWord(LED0, 0x0C, 0x01);
	sendWordToMax7219(0x0C01);

}


