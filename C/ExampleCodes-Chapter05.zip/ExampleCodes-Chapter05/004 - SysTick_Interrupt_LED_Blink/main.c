/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define DL_LED    100
#define SYST_RVR  1700000  // SysTick 10ms

volatile uint16_t  delayCnt=0;

void GPIO_Init(void);
void SysTick_Init(void);
void SysTick_Handler(void);

int main(void){
		
  GPIO_Init();
	SysTick_Init();
	
  for (;;) {
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
  GPIOA->MODER &= ~GPIO_MODER_MODE5;
  delay(5);
  GPIOA->MODER |= GPIO_MODER_MODE5_0;
  delay(5);
}


void SysTick_Init(void){
  /* Configure the SysTick to have interrupt in 1ms time base */
  SysTick->LOAD  = SYST_RVR;  /* set reload register */
  SysTick->VAL   = 0UL;                                       /* Load the SysTick Counter Value */
  SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk |
                   SysTick_CTRL_ENABLE_Msk |
	                 SysTick_CTRL_TICKINT_Msk;                  /* Enable the Systick Timer */
}


/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
*/
void SysTick_Handler(void){
	delayCnt++;
	if (delayCnt>100){
		delayCnt=0;
    GPIOA->ODR ^= (1<<5);
	}
}

