/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define EXTI9_5_IRQn_Pos   EXTI9_5_IRQn
#define EXTI9_5_IRQn_Msk   0x1 << EXTI9_5_IRQn_Pos 
#define EXTI9_5_IRQn_EN    EXTI9_5_IRQn_Msk

void GPIO_Init(void);
void EXTI9_5_IRQHandler(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
	
  for (;;) {
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);
  GPIOA->MODER &= ~GPIO_MODER_MODE5;
  delay(5);
  GPIOA->MODER |= GPIO_MODER_MODE5_0;
  delay(5);
	
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);
  GPIOB->MODER &= ~GPIO_MODER_MODE6;  // PB6 as an input
  delay(5);
  GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD6;
  GPIOB->PUPDR |= GPIO_PUPDR_PUPD6_0; // PUPD6 = 01 -> Pull-up
	
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
	SYSCFG->EXTICR[1] = SYSCFG_EXTICR2_EXTI6_PB;
	
	EXTI->IMR1 |= EXTI_IMR1_IM6;
	EXTI->RTSR1 |= EXTI_RTSR1_RT6;      // 
	
	EXTI->FTSR1 &= ~EXTI_FTSR1_FT6;
	
	//NVIC->ISER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
	NVIC->ISER[0] = EXTI9_5_IRQn_EN;
	NVIC->ISPR[0] = EXTI9_5_IRQn_EN;
}

void EXTI9_5_IRQHandler(void){
  if (((EXTI->PR1)&EXTI_PR1_PIF6) != RESET){
		EXTI->PR1 |= EXTI_PR1_PIF6;
    GPIOA->ODR ^= (1<<5);
  }
}

