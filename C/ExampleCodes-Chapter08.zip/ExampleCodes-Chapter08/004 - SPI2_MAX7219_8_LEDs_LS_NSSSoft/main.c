/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

#define MAX7219_CS          1<<12

void GPIO_Init(void);
void SPI2_Init(void);
void MAX7219_Init(void);
void SPI2_Transmit(uint16_t dataTX);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
  SPI2_Init();
  MAX7219_Init();

  SPI2_Transmit(0x0801);
  SPI2_Transmit(0x0702);
  SPI2_Transmit(0x0603);
  SPI2_Transmit(0x0504);
  SPI2_Transmit(0x0405);
  SPI2_Transmit(0x0306);
  SPI2_Transmit(0x0207);
  SPI2_Transmit(0x0108);
	
  for (;;) {
    delay(50000);	
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
  delay(5);
				
  // Enable output mode for PB12
  GPIOB->MODER &= ~GPIO_MODER_MODE12;
  GPIOB->MODER |= GPIO_MODER_MODE12_0;
	
  // PB13, PB14, PB15 in the alternate function mode
  GPIOB->MODER &= ~(GPIO_MODER_MODE13+GPIO_MODER_MODE14+GPIO_MODER_MODE15);
  GPIOB->MODER |= (GPIO_MODER_MODE13_1+GPIO_MODER_MODE14_1+GPIO_MODER_MODE15_1);
	
  GPIOB->AFR[1] &= ~(GPIO_AFRH_AFSEL13+GPIO_AFRH_AFSEL14+GPIO_AFRH_AFSEL15);
  GPIOB->AFR[1] |= (GPIO_AFRH_AFSEL13_0+GPIO_AFRH_AFSEL13_2
                   +GPIO_AFRH_AFSEL14_0+GPIO_AFRH_AFSEL14_2
                   +GPIO_AFRH_AFSEL15_0+GPIO_AFRH_AFSEL15_2);
  }

void SPI2_Init(void){
	
  // Enabled the clock to the SPI2
  RCC->APB1ENR1 |= RCC_APB1ENR1_SPI2EN;
  delay(5);
					
  // Configure the serial clock baud rate
  //SPI2->CR1 &= ~(SPI_CR1_BR);
  SPI2->CR1 |= (SPI_CR1_BR_0+SPI_CR1_BR_1+SPI_CR1_BR_2);
					
  // Configure the CPOL and CPHA bits
  SPI2->CR1 |= (SPI_CR1_CPOL+SPI_CR1_CPHA);

  // Select simplex or half-duplex mode, RXONLY = 0
  SPI2->CR1 &= ~(SPI_CR1_RXONLY);
					
  // Configure the LSBFIRST bit, MSB first
  SPI2->CR1 &= ~(SPI_CR1_LSBFIRST);

  // Configure the MSTR bit, Master Mode
  SPI2->CR1 |= (SPI_CR1_MSTR);

  // Software Slave Management
  SPI2->CR1 |= (SPI_CR1_SSI+SPI_CR1_SSM);
	
  // Configure the DS[3:0] bits to select 16 bit for the transfer.
  SPI2->CR2 |= SPI_CR2_DS;
					
  // Enable SPI
  SPI2->CR1 |= (SPI_CR1_SPE);
}

void SPI2_Transmit(uint16_t dataTX){
	
  GPIOB->ODR &= ~(MAX7219_CS);
  delay(5);

  while(((SPI2->SR)&(SPI_SR_TXE))==0){} // Wait for TXE bit to set
  SPI2->DR = dataTX;
  while(((SPI2->SR)&(SPI_SR_TXE))==0){} // Wait for buffer empty
  while(((SPI2->SR)&(SPI_SR_BSY))!=0){} // Wait for Busy flag 

  GPIOB->ODR |= (MAX7219_CS);
  delay(5);
}

void MAX7219_Init(void){
	// For test mode (all digits on) set to 0x01. 
	// Normally we want this off (0x0F)
	// sendWord(LED0, 0x0F, 0x00)
  SPI2_Transmit(0x0F00);

  // Set all digits off initially (0x0C)
  // sendWord(LED0, 0x0C, 0x00);
  SPI2_Transmit(0x0C00);

  // Set brightness for the digits to high(er) level than default minimum (Intensity Register Format)
  //  sendWord(LED0, 0x0A, 0x03);
  SPI2_Transmit(0x0A03);

  // Set decode mode for ALL digits to output actual ASCII chars rather than just
  // individual segments of a digit
  // sendWord(LED0, 0x09, 0xFF);
  SPI2_Transmit(0x09FF);

  // If first four digits not set it will display rubbish data (Code B Font) so use 'blank' from Register Data
  // sendWord(LED0, 0x01, 0x0F);
  SPI2_Transmit(0x010F);

  // sendWord(LED0, 0x02, 0x0F);
  SPI2_Transmit(0x020F);
					
  // sendWord(LED0, 0x03, 0x0F);
  SPI2_Transmit(0x030F);
					
  // sendWord(LED0, 0x04, 0x0F);
  SPI2_Transmit(0x040F);
					
  // sendWord(LED0, 0x05, 0x0F);
  SPI2_Transmit(0x050F);
					
  // sendWord(LED0, 0x06, 0x0F);
  SPI2_Transmit(0x060F);
					
  // sendWord(LED0, 0x07, 0x0F);
  SPI2_Transmit(0x070F);
					
  // sendWord(LED0, 0x08, 0x0F);
  SPI2_Transmit(0x080F);

  // Ensure ALL digits are displayed (Scan Limit Register)
  // sendWord(LED0, 0x0B, 0x07);
  SPI2_Transmit(0x0B07);

  // Turn display ON (boot up = shutdown display)
  // sendWord(LED0, 0x0C, 0x01);
  SPI2_Transmit(0x0C01);

}

