/**
  ******************************************************************************
  * @file    main.c
  * @author  Nguyen Tien Hung
  * @brief   Main program body from scrath
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

#include "main.h"

uint8_t data=0;

void GPIO_Init(void);
void USART2_Init(void);
void delay(volatile int i);

int main(void){
		
  GPIO_Init();
  USART2_Init();
	
  for (;;) {
		
    if (((USART2->ISR)&(USART_ISR_RXNE))!=0){
      data = USART2->RDR;
      USART2->TDR = data;
      while(((USART2->ISR)&(USART_ISR_TC))==0){}
    }
    delay(50000);
  }
}

void delay(volatile int i){
  while(i--) continue;
}

void GPIO_Init(void){
  RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
  delay(5);

  // Enable alternative function for PA2 and PA3
  GPIOA->MODER &= ~(GPIO_MODER_MODE2+GPIO_MODER_MODE3);
  GPIOA->MODER |= (GPIO_MODER_MODE2_1+GPIO_MODER_MODE3_1);
					
  // Select UART mode (AF7) for PA2, PA3
  GPIOA->AFR[0] &= ~(GPIO_AFRL_AFSEL2+GPIO_AFRL_AFSEL3);
  GPIOA->AFR[0] |= (GPIO_AFRL_AFSEL2_0+GPIO_AFRL_AFSEL2_1+GPIO_AFRL_AFSEL2_2
                   +GPIO_AFRL_AFSEL3_0+GPIO_AFRL_AFSEL3_1+GPIO_AFRL_AFSEL3_2);
}

void USART2_Init(void){
	
  //Enabled the clock to the USART by setting appropriate bits in register RCC_APB1ENR1
  RCC->APB1ENR1 |= RCC_APB1ENR1_USART2EN;

  // Specify Oversampling mode (bit OVER8) of register USART_CR1
  USART2->CR1 &= ~(USART_CR1_UE+USART_CR1_M0+USART_CR1_M1+USART_CR1_OVER8);
  USART2->CR1 |= (USART_CR1_RE+USART_CR1_TE);
					
  // Set UART Baud rate = 170.000.000/115.200 = 1476
  USART2->BRR = 1476;
					
  // Enable the USART
  USART2->CR1 |= USART_CR1_UE;
}



